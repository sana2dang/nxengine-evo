# sdl2
sudo add-apt-repository ppa:zoogie/sdl2-snapshots -y
# gcc
sudo add-apt-repository ppa:ubuntu-toolchain-r/test -y

sudo apt-get update -qq
sudo apt-get install -qq libsdl2-dev
sudo apt-get install -qq libsdl2-ttf-dev
sudo apt-get install -qq libpng-dev
sudo apt-get install -qq g++-6
